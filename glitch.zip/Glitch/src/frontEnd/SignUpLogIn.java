package frontEnd;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Border;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class SignUpLogIn extends Application {
    public static void main(String[] args) {
        launch(args);
    }
    public void start(Stage primaryStage) {
	 primaryStage.setTitle("SignUpLogIn Page");
	 Font font = Font.loadFont(getClass().getResourceAsStream("desdemon.ttf"), 60);
	 
	 //Login banner
	 Label LogIn = new Label("LogIn");
	 LogIn.setTranslateY(-200);
	 LogIn.setTranslateX(-400);
	 LogIn.setId("LogIn");
	 TextField liUsername = new TextField();
	 liUsername.setTranslateY(-150);
	 liUsername.setTranslateX(-400);
	 liUsername.setText("USERNAME");
	 liUsername.setMaxWidth(150);
	 liUsername.setId("liUsername");
	 TextField liPassword = new TextField();
	 liPassword.setTranslateY(-100);
	 liPassword.setTranslateX(-400);
	 liPassword.setText("PASSWORD");
	 liPassword.setMaxWidth(150);
	 Hyperlink liSubmit = new Hyperlink("Submit");
	 liSubmit.setTranslateY(-50);
	 liSubmit.setTranslateX(-425);
	 liSubmit.setBorder(Border.EMPTY);
	 liSubmit.setTextFill(Color.BLACK);
	 liSubmit.setId("liSubmit");
	 
	//Sign Up banner
	 Label SignUp = new Label("SignUp");
	 SignUp.setTranslateY(-200);
	 SignUp.setTranslateX(100);
	 SignUp.setId("SignUp");
	 TextField suUsername = new TextField();
	 suUsername.setTranslateY(-150);
	 suUsername.setTranslateX(100);
	 suUsername.setText("USERNAME");
	 suUsername.setMaxWidth(150);
	 TextField suEmail = new TextField();
	 suEmail.setTranslateY(-100);
	 suEmail.setTranslateX(100);
	 suEmail.setText("EMAIL");
	 suEmail.setMaxWidth(150);
	 TextField suPassword= new TextField();
	 suPassword.setTranslateY(-50);
	 suPassword.setTranslateX(100);
	 suPassword.setText("PASSWORD");
	 suPassword.setMaxWidth(150);
	 Hyperlink suSubmit = new Hyperlink("Submit");
	 suSubmit.setTranslateY(0);
	 suSubmit.setTranslateX(75);
	 suSubmit.setBorder(Border.EMPTY);
	 suSubmit.setTextFill(Color.BLACK);
	 suSubmit.setId("suSubmit");
	 
	 
	 StackPane root = new StackPane();
     root.getChildren().add(LogIn);
     root.getChildren().add(liUsername);
     root.getChildren().add(liPassword);
     root.getChildren().add(liSubmit);
     root.getChildren().add(SignUp);
     root.getChildren().add(suUsername);
     root.getChildren().add(suPassword);
     root.getChildren().add(suSubmit);
     root.getChildren().add(suEmail);
     Scene scene = new Scene(root, 1200, 800);
     primaryStage.setScene(scene);
     java.net.URL url = this.getClass().getResource("SignUpLogIn.css");
     if (url == null) {
         System.out.println("Resource not found. Aborting.");
         System.exit(-1);
     }
     String css = url.toExternalForm(); 
     scene.getStylesheets().add(css);
     primaryStage.show();
    }
}
